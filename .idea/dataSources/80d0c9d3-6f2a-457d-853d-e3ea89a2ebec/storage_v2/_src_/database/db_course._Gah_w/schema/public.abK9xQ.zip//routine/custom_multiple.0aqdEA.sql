create function custom_multiple(f custom_type, s custom_type) returns custom_type
    language sql
as
$$
select (f.x * s.x - f.y * s.y),(f.x * s.y + f.y * s.x);
$$;

alter function custom_multiple(custom_type, custom_type) owner to db_course;

