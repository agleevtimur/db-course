create function custom_diff(f custom_type, s custom_type) returns custom_type
    language sql
as
$$
select (f.x - s.y),(f.y - s.x);
$$;

alter function custom_diff(custom_type, custom_type) owner to db_course;

