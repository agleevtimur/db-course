create function custom_division(f custom_type, s custom_type) returns custom_type
    language sql
as
$$
select ((f.x * s.x + f.y * s.y)/(s.x * s.x + s.y * s.y)),((s.x * f.y - f.x * s.y)/(s.x * s.x + s.y * s.y));
$$;

alter function custom_division(custom_type, custom_type) owner to db_course;

